/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_298()
{
    return 2425393496U;
}

void setval_181(unsigned *p)
{
    *p = 3281031256U;
}

unsigned addval_386(unsigned x)
{
    return x + 3284633928U;
}

void setval_355(unsigned *p)
{
    *p = 3281012871U;
}

unsigned addval_208(unsigned x)
{
    return x + 2445773128U;
}

void setval_398(unsigned *p)
{
    *p = 2425378983U;
}

void setval_476(unsigned *p)
{
    *p = 3347662945U;
}

unsigned getval_256()
{
    return 3284634440U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_340(unsigned *p)
{
    *p = 1455673033U;
}

unsigned getval_349()
{
    return 3230977673U;
}

unsigned addval_114(unsigned x)
{
    return x + 2447411528U;
}

unsigned addval_477(unsigned x)
{
    return x + 3529559689U;
}

void setval_177(unsigned *p)
{
    *p = 3375944073U;
}

unsigned addval_357(unsigned x)
{
    return x + 2428666296U;
}

unsigned addval_104(unsigned x)
{
    return x + 3281047977U;
}

void setval_485(unsigned *p)
{
    *p = 2464188744U;
}

void setval_146(unsigned *p)
{
    *p = 2430634056U;
}

unsigned addval_220(unsigned x)
{
    return x + 3222851209U;
}

unsigned addval_200(unsigned x)
{
    return x + 3374367373U;
}

void setval_323(unsigned *p)
{
    *p = 3221799561U;
}

unsigned getval_361()
{
    return 3687109001U;
}

unsigned getval_448()
{
    return 2497743176U;
}

void setval_423(unsigned *p)
{
    *p = 3375944073U;
}

void setval_318(unsigned *p)
{
    *p = 3674784385U;
}

void setval_314(unsigned *p)
{
    *p = 3353381192U;
}

unsigned getval_132()
{
    return 2076365193U;
}

unsigned addval_315(unsigned x)
{
    return x + 3380924041U;
}

unsigned getval_411()
{
    return 2430634312U;
}

void setval_434(unsigned *p)
{
    *p = 3281047241U;
}

unsigned getval_118()
{
    return 3374367361U;
}

void setval_165(unsigned *p)
{
    *p = 3221802633U;
}

unsigned getval_201()
{
    return 3531919745U;
}

void setval_244(unsigned *p)
{
    *p = 3526410889U;
}

unsigned getval_109()
{
    return 3286272328U;
}

unsigned addval_329(unsigned x)
{
    return x + 3677930121U;
}

unsigned getval_379()
{
    return 3353381192U;
}

unsigned addval_154(unsigned x)
{
    return x + 3221802637U;
}

unsigned getval_189()
{
    return 3676361089U;
}

unsigned addval_483(unsigned x)
{
    return x + 2425409993U;
}

unsigned addval_301(unsigned x)
{
    return x + 3223896713U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
